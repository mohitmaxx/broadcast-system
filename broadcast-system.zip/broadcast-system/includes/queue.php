<?php

if (!defined('APP_START')) {
    exit('No direct script access allowed');
}

/*
|--------------------------------------------------------------------------
| CREATE QUEUE
|--------------------------------------------------------------------------
*/

function createBroadcastQueue($broadcastId)
{
    global $pdo;

    $stmt = $pdo->prepare("
        INSERT INTO broadcast_queue
        (
            broadcast_id,
            user_id,
            chat_id,
            status,
            retry_count,
            created_at
        )
        SELECT
            ?,
            id,
            chat_id,
            'pending',
            0,
            NOW()
        FROM users
        WHERE is_active = 1
    ");

    $stmt->execute([$broadcastId]);

    return $stmt->rowCount();
}

/*
|--------------------------------------------------------------------------
| TOTAL QUEUE
|--------------------------------------------------------------------------
*/

function totalQueue($broadcastId)
{
    global $pdo;

    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM broadcast_queue
        WHERE broadcast_id=?
    ");

    $stmt->execute([$broadcastId]);

    return (int)$stmt->fetchColumn();
}

/*
|--------------------------------------------------------------------------
| PENDING QUEUE
|--------------------------------------------------------------------------
*/

function pendingQueue($broadcastId)
{
    global $pdo;

    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM broadcast_queue
        WHERE broadcast_id=?
        AND status='pending'
    ");

    $stmt->execute([$broadcastId]);

    return (int)$stmt->fetchColumn();
}

/*
|--------------------------------------------------------------------------
| SUCCESS QUEUE
|--------------------------------------------------------------------------
*/

function successQueue($broadcastId)
{
    global $pdo;

    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM broadcast_queue
        WHERE broadcast_id=?
        AND status='success'
    ");

    $stmt->execute([$broadcastId]);

    return (int)$stmt->fetchColumn();
}

/*
|--------------------------------------------------------------------------
| FAILED QUEUE
|--------------------------------------------------------------------------
*/

function failedQueue($broadcastId)
{
    global $pdo;

    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM broadcast_queue
        WHERE broadcast_id=?
        AND status='failed'
    ");

    $stmt->execute([$broadcastId]);

    return (int)$stmt->fetchColumn();
}

/*
|--------------------------------------------------------------------------
| RETRY QUEUE
|--------------------------------------------------------------------------
*/

function retryQueue($broadcastId)
{
    global $pdo;

    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM broadcast_queue
        WHERE broadcast_id=?
        AND status='retry'
    ");

    $stmt->execute([$broadcastId]);

    return (int)$stmt->fetchColumn();
}

/*
|--------------------------------------------------------------------------
| GET NEXT BATCH
|--------------------------------------------------------------------------
*/

function getQueueBatch(
    $broadcastId,
    $limit = BATCH_SIZE
)
{
    global $pdo;

    $stmt = $pdo->prepare("
        SELECT *
        FROM broadcast_queue
        WHERE broadcast_id=?
        AND status IN ('pending','retry')
        ORDER BY id ASC
        LIMIT $limit
    ");

    $stmt->execute([$broadcastId]);

    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/*
|--------------------------------------------------------------------------
| GET QUEUE BY ID
|--------------------------------------------------------------------------
*/

function getQueue($id)
{
    global $pdo;

    $stmt = $pdo->prepare("
        SELECT *
        FROM broadcast_queue
        WHERE id=?
        LIMIT 1
    ");

    $stmt->execute([$id]);

    return $stmt->fetch(PDO::FETCH_ASSOC);
}

/*
|--------------------------------------------------------------------------
| MARK SUCCESS
|--------------------------------------------------------------------------
*/

function markQueueSuccess(
    $queueId,
    $messageId = null
)
{
    global $pdo;

    $stmt = $pdo->prepare("
        UPDATE broadcast_queue
        SET
            status='success',
            telegram_message_id=?,
            completed_at=NOW(),
            updated_at=NOW()
        WHERE id=?
    ");

    return $stmt->execute([
        $messageId,
        $queueId
    ]);
}

/*
|--------------------------------------------------------------------------
| MARK FAILED
|--------------------------------------------------------------------------
*/

function markQueueFailed(
    $queueId,
    $error = ''
)
{
    global $pdo;

    $stmt = $pdo->prepare("
        UPDATE broadcast_queue
        SET
            status='failed',
            last_error=?,
            completed_at=NOW(),
            updated_at=NOW()
        WHERE id=?
    ");

    return $stmt->execute([
        mb_substr($error, 0, 1000),
        $queueId
    ]);
}

/*
|--------------------------------------------------------------------------
| MARK RETRY
|--------------------------------------------------------------------------
*/

function markQueueRetry(
    $queueId,
    $error = ''
)
{
    global $pdo;

    $stmt = $pdo->prepare("
        UPDATE broadcast_queue
        SET
            status='retry',
            retry_count=retry_count+1,
            last_error=?,
            updated_at=NOW()
        WHERE id=?
    ");

    return $stmt->execute([
        mb_substr($error, 0, 1000),
        $queueId
    ]);
}

/*
|--------------------------------------------------------------------------
| UPDATE MESSAGE ID
|--------------------------------------------------------------------------
*/

function updateTelegramMessageId(
    $queueId,
    $messageId
)
{
    global $pdo;

    $stmt = $pdo->prepare("
        UPDATE broadcast_queue
        SET
            telegram_message_id=?,
            updated_at=NOW()
        WHERE id=?
    ");

    return $stmt->execute([
        $messageId,
        $queueId
    ]);
}

/*
|--------------------------------------------------------------------------
| UPDATE LAST ERROR
|--------------------------------------------------------------------------
*/

function updateQueueError(
    $queueId,
    $error
)
{
    global $pdo;

    $stmt = $pdo->prepare("
        UPDATE broadcast_queue
        SET
            last_error=?,
            updated_at=NOW()
        WHERE id=?
    ");

    return $stmt->execute([
        mb_substr($error, 0, 1000),
        $queueId
    ]);
}

/*
|--------------------------------------------------------------------------
| RESET RETRY
|--------------------------------------------------------------------------
*/

function resetQueueRetry($queueId)
{
    global $pdo;

    $stmt = $pdo->prepare("
        UPDATE broadcast_queue
        SET
            retry_count=0,
            updated_at=NOW()
        WHERE id=?
    ");

    return $stmt->execute([
        $queueId
    ]);
}

/*
|--------------------------------------------------------------------------
| LOCK BATCH
|--------------------------------------------------------------------------
*/

function lockQueueBatch(array $ids)
{
    global $pdo;

    if (empty($ids)) {
        return true;
    }

    $placeholders = implode(
        ',',
        array_fill(0, count($ids), '?')
    );

    $stmt = $pdo->prepare("
        UPDATE broadcast_queue
        SET
            status='processing',
            updated_at=NOW()
        WHERE id IN ($placeholders)
        AND status IN ('pending','retry')
    ");

    return $stmt->execute($ids);
}

/*
|--------------------------------------------------------------------------
| UNLOCK BATCH
|--------------------------------------------------------------------------
*/

function unlockQueueBatch(array $ids)
{
    global $pdo;

    if (empty($ids)) {
        return true;
    }

    $placeholders = implode(
        ',',
        array_fill(0, count($ids), '?')
    );

    $stmt = $pdo->prepare("
        UPDATE broadcast_queue
        SET
            status='retry',
            updated_at=NOW()
        WHERE id IN ($placeholders)
        AND status='processing'
    ");

    return $stmt->execute($ids);
}

/*
|--------------------------------------------------------------------------
| REMAINING QUEUE
|--------------------------------------------------------------------------
*/

function remainingQueue($broadcastId)
{
    global $pdo;

    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM broadcast_queue
        WHERE broadcast_id=?
        AND status IN ('pending','retry','processing')
    ");

    $stmt->execute([$broadcastId]);

    return (int)$stmt->fetchColumn();
}

/*
|--------------------------------------------------------------------------
| BROADCAST PROGRESS
|--------------------------------------------------------------------------
*/

function queueProgress($broadcastId)
{
    $total = totalQueue($broadcastId);

    if ($total <= 0) {
        return 0;
    }

    $completed =
        successQueue($broadcastId) +
        failedQueue($broadcastId);

    return round(
        ($completed / $total) * 100,
        2
    );
}

/*
|--------------------------------------------------------------------------
| IS BROADCAST FINISHED
|--------------------------------------------------------------------------
*/

function isBroadcastFinished($broadcastId)
{
    return remainingQueue($broadcastId) === 0;
}

/*
|--------------------------------------------------------------------------
| GET RETRY ITEMS
|--------------------------------------------------------------------------
*/

function getRetryQueue(
    $broadcastId,
    $limit = BATCH_SIZE
)
{
    global $pdo;

    $stmt = $pdo->prepare("
        SELECT *
        FROM broadcast_queue
        WHERE broadcast_id=?
        AND status='retry'
        AND retry_count < ?
        ORDER BY id ASC
        LIMIT $limit
    ");

    $stmt->execute([
        $broadcastId,
        MAX_RETRY
    ]);

    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/*
|--------------------------------------------------------------------------
| DELETE QUEUE
|--------------------------------------------------------------------------
*/

function deleteQueue($broadcastId)
{
    global $pdo;

    $stmt = $pdo->prepare("
        DELETE FROM broadcast_queue
        WHERE broadcast_id=?
    ");

    return $stmt->execute([
        $broadcastId
    ]);
}

/*
|--------------------------------------------------------------------------
| CLEAN COMPLETED QUEUE
|--------------------------------------------------------------------------
*/

function cleanupCompletedQueue($days = 30)
{
    global $pdo;

    $stmt = $pdo->prepare("
        DELETE FROM broadcast_queue
        WHERE completed_at IS NOT NULL
        AND completed_at < DATE_SUB(
            NOW(),
            INTERVAL ? DAY
        )
    ");

    return $stmt->execute([
        $days
    ]);
}

/*
|--------------------------------------------------------------------------
| QUEUE STATISTICS
|--------------------------------------------------------------------------
*/

function queueStatistics($broadcastId)
{
    return [

        'total'      => totalQueue($broadcastId),

        'pending'    => pendingQueue($broadcastId),

        'processing' => remainingQueue($broadcastId)
                         - pendingQueue($broadcastId)
                         - retryQueue($broadcastId),

        'retry'      => retryQueue($broadcastId),

        'success'    => successQueue($broadcastId),

        'failed'     => failedQueue($broadcastId),

        'progress'   => queueProgress($broadcastId)

    ];
}

/*
|--------------------------------------------------------------------------
| QUEUE IDS
|--------------------------------------------------------------------------
*/

function queueIds(array $rows)
{
    return array_column($rows, 'id');
}

/*
|--------------------------------------------------------------------------
| HAS PENDING QUEUE
|--------------------------------------------------------------------------
*/

function hasPendingQueue($broadcastId)
{
    return remainingQueue($broadcastId) > 0;
}

/*
|--------------------------------------------------------------------------
| NEXT QUEUE ID
|--------------------------------------------------------------------------
*/

function nextQueueId($broadcastId)
{
    global $pdo;

    $stmt = $pdo->prepare("
        SELECT id
        FROM broadcast_queue
        WHERE broadcast_id=?
        AND status IN (
            'pending',
            'retry'
        )
        ORDER BY id ASC
        LIMIT 1
    ");

    $stmt->execute([
        $broadcastId
    ]);

    return (int)$stmt->fetchColumn();
}

/*
|--------------------------------------------------------------------------
| RESET FAILED TO RETRY
|--------------------------------------------------------------------------
*/

function retryFailedQueue($broadcastId)
{
    global $pdo;

    $stmt = $pdo->prepare("
        UPDATE broadcast_queue
        SET
            status='retry',
            updated_at=NOW()
        WHERE broadcast_id=?
        AND status='failed'
        AND retry_count < ?
    ");

    return $stmt->execute([
        $broadcastId,
        MAX_RETRY
    ]);
}
