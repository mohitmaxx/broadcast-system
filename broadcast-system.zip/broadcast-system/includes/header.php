<?php

if (!defined('APP_START')) {
    exit('No direct script access allowed');
}

$admin = currentAdmin();
$pageTitle = $pageTitle ?? APP_NAME;
?>
<!doctype html>
<html lang="en">

<head>

<meta charset="utf-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1">

<title><?=e($pageTitle)?></title>

<meta
    name="csrf-token"
    content="<?=csrfToken()?>">

<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<link
href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css"
rel="stylesheet">

<link
href="<?=BASE_URL?>assets/css/admin.css"
rel="stylesheet">

</head>

<body>

<nav class="navbar navbar-dark bg-dark navbar-expand-lg">

<div class="container-fluid">

<a
class="navbar-brand fw-bold"
href="<?=BASE_URL?>index.php">

<?=APP_NAME?>

</a>

<button
class="navbar-toggler"
data-bs-toggle="collapse"
data-bs-target="#navbarMain">

<span class="navbar-toggler-icon"></span>

</button>

<div
class="collapse navbar-collapse"
id="navbarMain">

<ul class="navbar-nav me-auto">

<li class="nav-item">

<a
class="nav-link"
href="<?=BASE_URL?>index.php">

Dashboard

</a>

</li>

<li class="nav-item">

<a
class="nav-link"
href="<?=BASE_URL?>broadcast.php">

Broadcast

</a>

</li>

<li class="nav-item">

<a
class="nav-link"
href="<?=BASE_URL?>history.php">

History

</a>

</li>

</ul>

<ul class="navbar-nav ms-auto">

<?php if($admin): ?>

<li class="nav-item dropdown">

<a
class="nav-link dropdown-toggle"
href="#"
data-bs-toggle="dropdown">

<i class="bi bi-person-circle"></i>

<?=e($admin['username'])?>

</a>

<ul class="dropdown-menu dropdown-menu-end">

<li>

<a
class="dropdown-item"
href="<?=BASE_URL?>logout.php">

Logout

</a>

</li>

</ul>

</li>

<?php endif; ?>

</ul>

</div>

</div>

</nav>

<div class="container-fluid mt-4">

<?php if($msg = getSuccess()): ?>

<div
class="alert alert-success alert-dismissible fade show">

<?=$msg?>

<button
class="btn-close"
data-bs-dismiss="alert">
</button>

</div>

<?php endif; ?>

<?php if($msg = getError()): ?>

<div
class="alert alert-danger alert-dismissible fade show">

<?=$msg?>

<button
class="btn-close"
data-bs-dismiss="alert">
</button>

</div>

<?php endif; ?>

<?php

if (!empty($pageHeading)):
?>

<div class="row mb-4">

    <div class="col-12">

        <div class="d-flex
                    justify-content-between
                    align-items-center">

            <div>

                <h3 class="mb-1">

                    <?=e($pageHeading)?>

                </h3>

                <?php if (!empty($pageDescription)): ?>

                    <div class="text-muted">

                        <?=e($pageDescription)?>

                    </div>

                <?php endif; ?>

            </div>

        </div>

    </div>

</div>

<?php endif; ?>

<div id="ajaxLoading"
     class="position-fixed
            top-0
            start-0
            w-100
            h-100
            d-none
            bg-dark
            bg-opacity-25"
     style="
        z-index:9999;
    ">

    <div class="
        d-flex
        justify-content-center
        align-items-center
        h-100">

        <div
            class="spinner-border
                   text-light"
            role="status">

            <span class="visually-hidden">
                Loading...
            </span>

        </div>

    </div>

</div>

<div
    class="toast-container
           position-fixed
           bottom-0
           end-0
           p-3"
    id="toastContainer">

</div>

<div
    class="modal fade"
    id="globalModal"
    tabindex="-1">

    <div class="modal-dialog modal-lg">

        <div class="modal-content">

            <div class="modal-header">

                <h5
                    class="modal-title">

                    <?=APP_NAME?>

                </h5>

                <button
                    class="btn-close"
                    data-bs-dismiss="modal">

                </button>

            </div>

            <div
                class="modal-body"
                id="globalModalBody">

            </div>

        </div>

    </div>

</div>

<main id="appContent">