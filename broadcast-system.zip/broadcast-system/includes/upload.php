<?php

if (!defined('APP_START')) {
    exit('No direct script access allowed');
}

/*
|--------------------------------------------------------------------------
| ALLOWED FILES
|--------------------------------------------------------------------------
*/

define('ALLOWED_PHOTO_EXT', [
    'jpg',
    'jpeg',
    'png',
    'webp'
]);

define('ALLOWED_VIDEO_EXT', [
    'mp4',
    'mov',
    'mkv',
    'avi'
]);

define('ALLOWED_DOCUMENT_EXT', [
    'pdf',
    'zip',
    'rar',
    'txt',
    'doc',
    'docx',
    'xls',
    'xlsx'
]);

/*
|--------------------------------------------------------------------------
| MIME TYPES
|--------------------------------------------------------------------------
*/

define('PHOTO_MIME', [
    'image/jpeg',
    'image/png',
    'image/webp'
]);

define('VIDEO_MIME', [
    'video/mp4',
    'video/quicktime',
    'video/x-msvideo',
    'video/x-matroska'
]);

define('DOCUMENT_MIME', [
    'application/pdf',
    'application/zip',
    'application/x-rar-compressed',
    'text/plain',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.ms-excel',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
]);

/*
|--------------------------------------------------------------------------
| VALIDATE FILE
|--------------------------------------------------------------------------
*/

function validateUpload($file, $allowedExt, $allowedMime)
{
    if (empty($file['name'])) {
        return 'No file selected.';
    }

    if ($file['error'] !== UPLOAD_ERR_OK) {
        return 'Upload failed.';
    }

    if ($file['size'] > MAX_FILE_SIZE) {
        return 'File size exceeds limit.';
    }

    $extension = strtolower(
        pathinfo($file['name'], PATHINFO_EXTENSION)
    );

    if (!in_array($extension, $allowedExt)) {
        return 'Invalid file extension.';
    }

    $mime = mime_content_type($file['tmp_name']);

    if (!in_array($mime, $allowedMime)) {
        return 'Invalid MIME type.';
    }

    return true;
}

/*
|--------------------------------------------------------------------------
| SAVE FILE
|--------------------------------------------------------------------------
*/

function saveUpload($file, $directory)
{
    makeDirectory($directory);

    $name = generateFileName($file['name']);

    $destination = $directory . $name;

    if (!move_uploaded_file(
        $file['tmp_name'],
        $destination
    )) {
        return false;
    }

    return $name;
}

/*
|--------------------------------------------------------------------------
| PHOTO
|--------------------------------------------------------------------------
*/

function uploadPhoto($field)
{
    if (empty($_FILES[$field])) {
        return false;
    }

    $file = $_FILES[$field];

    $check = validateUpload(
        $file,
        ALLOWED_PHOTO_EXT,
        PHOTO_MIME
    );

    if ($check !== true) {
        throw new Exception($check);
    }

    return saveUpload(
        $file,
        PHOTO_PATH
    );
}

/*
|--------------------------------------------------------------------------
| VIDEO
|--------------------------------------------------------------------------
*/

function uploadVideo($field)
{
    if (empty($_FILES[$field])) {
        return false;
    }

    $file = $_FILES[$field];

    $check = validateUpload(
        $file,
        ALLOWED_VIDEO_EXT,
        VIDEO_MIME
    );

    if ($check !== true) {
        throw new Exception($check);
    }

    return saveUpload(
        $file,
        VIDEO_PATH
    );
}

/*
|--------------------------------------------------------------------------
| DOCUMENT
|--------------------------------------------------------------------------
*/

function uploadDocument($field)
{
    if (empty($_FILES[$field])) {
        return false;
    }

    $file = $_FILES[$field];

    $check = validateUpload(
        $file,
        ALLOWED_DOCUMENT_EXT,
        DOCUMENT_MIME
    );

    if ($check !== true) {
        throw new Exception($check);
    }

    return saveUpload(
        $file,
        DOCUMENT_PATH
    );
}

/*
|--------------------------------------------------------------------------
| DELETE FILE
|--------------------------------------------------------------------------
*/

function deleteUploadedFile($path)
{
    if (
        !empty($path)
        &&
        file_exists($path)
    ) {
        unlink($path);
    }
}
/*
|--------------------------------------------------------------------------
| MULTIPLE PHOTO UPLOAD
|--------------------------------------------------------------------------
*/

function uploadPhotos($field = 'photos')
{
    $uploaded = [];

    if (
        empty($_FILES[$field]) ||
        empty($_FILES[$field]['name'][0])
    ) {
        return [];
    }

    $total = count($_FILES[$field]['name']);

    if ($total > MAX_PHOTOS) {
        throw new Exception(
            "Maximum ".MAX_PHOTOS." photos allowed."
        );
    }

    for ($i = 0; $i < $total; $i++) {

        $file = [

            'name'     => $_FILES[$field]['name'][$i],
            'type'     => $_FILES[$field]['type'][$i],
            'tmp_name' => $_FILES[$field]['tmp_name'][$i],
            'error'    => $_FILES[$field]['error'][$i],
            'size'     => $_FILES[$field]['size'][$i]

        ];

        $check = validateUpload(
            $file,
            ALLOWED_PHOTO_EXT,
            PHOTO_MIME
        );

        if ($check !== true) {

            foreach ($uploaded as $image) {

                deleteUploadedFile(
                    PHOTO_PATH.$image
                );

            }

            throw new Exception($check);
        }

        $filename = saveUpload(
            $file,
            PHOTO_PATH
        );

        if (!$filename) {

            foreach ($uploaded as $image) {

                deleteUploadedFile(
                    PHOTO_PATH.$image
                );

            }

            throw new Exception(
                'Failed to upload image.'
            );
        }

        $uploaded[] = $filename;
    }

    return $uploaded;
}

/*
|--------------------------------------------------------------------------
| MEDIA JSON
|--------------------------------------------------------------------------
*/

function mediaJson(array $files)
{
    return json_encode(
        array_values($files),
        JSON_UNESCAPED_UNICODE
    );
}

/*
|--------------------------------------------------------------------------
| MEDIA ARRAY
|--------------------------------------------------------------------------
*/

function mediaFiles($json)
{
    if (empty($json)) {
        return [];
    }

    $files = json_decode(
        $json,
        true
    );

    return is_array($files)
        ? $files
        : [];
}

/*
|--------------------------------------------------------------------------
| DELETE PHOTO
|--------------------------------------------------------------------------
*/

function deletePhoto($file)
{
    deleteUploadedFile(
        PHOTO_PATH.basename($file)
    );
}

/*
|--------------------------------------------------------------------------
| DELETE VIDEO
|--------------------------------------------------------------------------
*/

function deleteVideo($file)
{
    deleteUploadedFile(
        VIDEO_PATH.basename($file)
    );
}

/*
|--------------------------------------------------------------------------
| DELETE DOCUMENT
|--------------------------------------------------------------------------
*/

function deleteDocument($file)
{
    deleteUploadedFile(
        DOCUMENT_PATH.basename($file)
    );
}

/*
|--------------------------------------------------------------------------
| DELETE PHOTO ARRAY
|--------------------------------------------------------------------------
*/

function deletePhotos(array $photos)
{
    foreach ($photos as $photo) {

        deletePhoto($photo);

    }
}

/*
|--------------------------------------------------------------------------
| CLEANUP MEDIA
|--------------------------------------------------------------------------
*/

function cleanupMedia($type, $media)
{
    if (empty($media)) {
        return;
    }

    switch ($type) {

        case 'album':

            deletePhotos(
                mediaFiles($media)
            );

        break;

        case 'photo':

            deletePhoto($media);

        break;

        case 'video':

            deleteVideo($media);

        break;

        case 'document':

            deleteDocument($media);

        break;
    }
}

/*
|--------------------------------------------------------------------------
| PROCESS BROADCAST UPLOAD
|--------------------------------------------------------------------------
*/

function processBroadcastUpload($type)
{
    switch ($type) {

        case 'text':

            return '';

        case 'photo':

            return uploadPhoto('photo');

        case 'album':

            return mediaJson(
                uploadPhotos('photos')
            );

        case 'video':

            return uploadVideo('video');

        case 'document':

            return uploadDocument('document');

        default:

            throw new Exception(
                'Invalid media type.'
            );
    }
}

/*
|--------------------------------------------------------------------------
| FILE URL
|--------------------------------------------------------------------------
*/

function mediaUrl($type, $file)
{
    switch ($type) {

        case 'photo':
            return PHOTO_URL.$file;

        case 'video':
            return VIDEO_URL.$file;

        case 'document':
            return DOCUMENT_URL.$file;

        default:
            return '';
    }
}

/*
|--------------------------------------------------------------------------
| MEDIA EXISTS
|--------------------------------------------------------------------------
*/

function mediaFileExists($type, $file)
{
    switch ($type) {

        case 'photo':
            return file_exists(
                PHOTO_PATH.$file
            );

        case 'video':
            return file_exists(
                VIDEO_PATH.$file
            );

        case 'document':
            return file_exists(
                DOCUMENT_PATH.$file
            );

        default:
            return false;
    }
}

/*
|--------------------------------------------------------------------------
| DELETE ALL MEDIA
|--------------------------------------------------------------------------
*/

function deleteBroadcastMedia(
    $type,
    $media
)
{
    cleanupMedia(
        $type,
        $media
    );
}
