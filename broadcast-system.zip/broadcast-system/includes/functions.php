<?php

if (!defined('APP_START')) {
    exit('No direct script access allowed');
}

require_once __DIR__.'/../config/telegram.php';

/*
|--------------------------------------------------------------------------
| SETTINGS
|--------------------------------------------------------------------------
*/

function getSettings()
{
    global $pdo;

    static $settings = null;

    if ($settings !== null) {
        return $settings;
    }

    $stmt = $pdo->query("SELECT * FROM settings LIMIT 1");

    $settings = $stmt->fetch();

    return $settings;
}

/*
|--------------------------------------------------------------------------
| UPDATE SETTING
|--------------------------------------------------------------------------
*/

function updateSetting($key, $value)
{
    global $pdo;

    $sql = "UPDATE settings SET {$key}=? LIMIT 1";

    $stmt = $pdo->prepare($sql);

    return $stmt->execute([$value]);
}

/*
|--------------------------------------------------------------------------
| GET TOTAL USERS
|--------------------------------------------------------------------------
*/

function totalUsers()
{
    global $pdo;

    return (int)$pdo
        ->query("SELECT COUNT(*) FROM users")
        ->fetchColumn();
}

/*
|--------------------------------------------------------------------------
| GET ACTIVE USERS
|--------------------------------------------------------------------------
*/

function activeUsers()
{
    global $pdo;

    return (int)$pdo
        ->query("SELECT COUNT(*) FROM users WHERE is_active=1")
        ->fetchColumn();
}

/*
|--------------------------------------------------------------------------
| GET BLOCKED USERS
|--------------------------------------------------------------------------
*/

function blockedUsers()
{
    global $pdo;

    return (int)$pdo
        ->query("SELECT COUNT(*) FROM users WHERE is_active=0")
        ->fetchColumn();
}

/*
|--------------------------------------------------------------------------
| LAST BROADCAST
|--------------------------------------------------------------------------
*/

function lastBroadcast()
{
    global $pdo;

    $stmt=$pdo->query("
        SELECT *
        FROM broadcasts
        ORDER BY id DESC
        LIMIT 1
    ");

    return $stmt->fetch();
}

/*
|--------------------------------------------------------------------------
| BROADCAST COUNT
|--------------------------------------------------------------------------
*/

function totalBroadcasts()
{
    global $pdo;

    return (int)$pdo
        ->query("SELECT COUNT(*) FROM broadcasts")
        ->fetchColumn();
}

/*
|--------------------------------------------------------------------------
| GET BROADCAST
|--------------------------------------------------------------------------
*/

function getBroadcast($id)
{
    global $pdo;

    $stmt=$pdo->prepare("
        SELECT *
        FROM broadcasts
        WHERE id=?
        LIMIT 1
    ");

    $stmt->execute([$id]);

    return $stmt->fetch();
}

/*
|--------------------------------------------------------------------------
| BROADCAST STATUS
|--------------------------------------------------------------------------
*/

function broadcastRunning()
{
    global $pdo;

    return (int)$pdo
        ->query("
            SELECT COUNT(*)
            FROM broadcasts
            WHERE status='running'
        ")
        ->fetchColumn();
}

/*
|--------------------------------------------------------------------------
| CREATE BROADCAST
|--------------------------------------------------------------------------
*/

function createBroadcast($data)
{
    global $pdo;

    $stmt=$pdo->prepare("
        INSERT INTO broadcasts
        (
            title,
            type,
            message,
            media,
            buttons,
            total_users,
            pending_count,
            status
        )
        VALUES
        (
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            'pending'
        )
    ");

    $stmt->execute([

        $data['title'],

        $data['type'],

        $data['message'],

        $data['media'],

        $data['buttons'],

        $data['total_users'],

        $data['pending_count']

    ]);

    return $pdo->lastInsertId();
}

/*
|--------------------------------------------------------------------------
| UPDATE BROADCAST STATUS
|--------------------------------------------------------------------------
*/

function updateBroadcastStatus($id,$status)
{
    global $pdo;

    $stmt=$pdo->prepare("
        UPDATE broadcasts
        SET status=?
        WHERE id=?
    ");

    return $stmt->execute([
        $status,
        $id
    ]);
}

/*
|--------------------------------------------------------------------------
| START BROADCAST
|--------------------------------------------------------------------------
*/

function startBroadcast($id)
{
    global $pdo;

    $stmt=$pdo->prepare("
        UPDATE broadcasts
        SET
        status='running',
        started_at=NOW()
        WHERE id=?
    ");

    return $stmt->execute([$id]);
}

/*
|--------------------------------------------------------------------------
| COMPLETE BROADCAST
|--------------------------------------------------------------------------
*/

function completeBroadcast($id)
{
    global $pdo;

    $stmt=$pdo->prepare("
        UPDATE broadcasts
        SET
        status='completed',
        completed_at=NOW()
        WHERE id=?
    ");

    return $stmt->execute([$id]);
}

/*
|--------------------------------------------------------------------------
| DELETE BROADCAST
|--------------------------------------------------------------------------
*/

function deleteBroadcast($id)
{
    global $pdo;

    $stmt=$pdo->prepare("
        DELETE FROM broadcasts
        WHERE id=?
    ");

    return $stmt->execute([$id]);
}

/*
|--------------------------------------------------------------------------
| GET ACTIVE CHAT IDS
|--------------------------------------------------------------------------
*/

function activeChatIds()
{
    global $pdo;

    $stmt=$pdo->query("
        SELECT chat_id
        FROM users
        WHERE is_active=1
        ORDER BY id ASC
    ");

    return $stmt->fetchAll(PDO::FETCH_COLUMN);
}

/*
|--------------------------------------------------------------------------
| GET USER
|--------------------------------------------------------------------------
*/

function getUser($chatId)
{
    global $pdo;

    $stmt=$pdo->prepare("
        SELECT *
        FROM users
        WHERE chat_id=?
        LIMIT 1
    ");

    $stmt->execute([$chatId]);

    return $stmt->fetch();
}
/*
|--------------------------------------------------------------------------
| TOTAL QUEUE
|--------------------------------------------------------------------------
*/

function totalQueue($broadcastId)
{
    global $pdo;

    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM broadcast_queue
        WHERE broadcast_id=?
    ");

    $stmt->execute([$broadcastId]);

    return (int)$stmt->fetchColumn();
}

/*
|--------------------------------------------------------------------------
| PENDING QUEUE
|--------------------------------------------------------------------------
*/

function pendingQueue($broadcastId)
{
    global $pdo;

    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM broadcast_queue
        WHERE broadcast_id=?
        AND status=0
    ");

    $stmt->execute([$broadcastId]);

    return (int)$stmt->fetchColumn();
}

/*
|--------------------------------------------------------------------------
| SENDING QUEUE
|--------------------------------------------------------------------------
*/

function sendingQueue($broadcastId)
{
    global $pdo;

    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM broadcast_queue
        WHERE broadcast_id=?
        AND status=1
    ");

    $stmt->execute([$broadcastId]);

    return (int)$stmt->fetchColumn();
}

/*
|--------------------------------------------------------------------------
| SENT QUEUE
|--------------------------------------------------------------------------
*/

function sentQueue($broadcastId)
{
    global $pdo;

    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM broadcast_queue
        WHERE broadcast_id=?
        AND status=2
    ");

    $stmt->execute([$broadcastId]);

    return (int)$stmt->fetchColumn();
}

/*
|--------------------------------------------------------------------------
| FAILED QUEUE
|--------------------------------------------------------------------------
*/

function failedQueue($broadcastId)
{
    global $pdo;

    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM broadcast_queue
        WHERE broadcast_id=?
        AND status=3
    ");

    $stmt->execute([$broadcastId]);

    return (int)$stmt->fetchColumn();
}

/*
|--------------------------------------------------------------------------
| BLOCKED QUEUE
|--------------------------------------------------------------------------
*/

function blockedQueue($broadcastId)
{
    global $pdo;

    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM broadcast_queue
        WHERE broadcast_id=?
        AND status=4
    ");

    $stmt->execute([$broadcastId]);

    return (int)$stmt->fetchColumn();
}

/*
|--------------------------------------------------------------------------
| UPDATE BROADCAST COUNTERS
|--------------------------------------------------------------------------
*/

function updateBroadcastCounters($broadcastId)
{
    global $pdo;

    $pending = pendingQueue($broadcastId);
    $sent    = sentQueue($broadcastId);
    $failed  = failedQueue($broadcastId);
    $blocked = blockedQueue($broadcastId);

    $stmt = $pdo->prepare("
        UPDATE broadcasts
        SET
            pending_count=?,
            sent_count=?,
            failed_count=?,
            blocked_count=?
        WHERE id=?
    ");

    return $stmt->execute([
        $pending,
        $sent,
        $failed,
        $blocked,
        $broadcastId
    ]);
}

/*
|--------------------------------------------------------------------------
| BROADCAST PROGRESS
|--------------------------------------------------------------------------
*/

function broadcastProgress($broadcastId)
{
    $total = totalQueue($broadcastId);

    if ($total == 0) {
        return 0;
    }

    $completed =
        sentQueue($broadcastId)
        +
        failedQueue($broadcastId)
        +
        blockedQueue($broadcastId);

    return round(($completed / $total) * 100, 2);
}

/*
|--------------------------------------------------------------------------
| ETA
|--------------------------------------------------------------------------
*/

function broadcastETA($broadcastId)
{
    global $pdo;

    $broadcast = getBroadcast($broadcastId);

    if (!$broadcast) {
        return '-';
    }

    if (empty($broadcast['started_at'])) {
        return '-';
    }

    $sent = sentQueue($broadcastId);

    if ($sent == 0) {
        return '-';
    }

    $elapsed = time() - strtotime($broadcast['started_at']);

    $perUser = $elapsed / $sent;

    $remaining = pendingQueue($broadcastId);

    $eta = round($remaining * $perUser);

    return gmdate("H:i:s", $eta);
}

/*
|--------------------------------------------------------------------------
| MARK QUEUE SENDING
|--------------------------------------------------------------------------
*/

function queueSending($queueId)
{
    global $pdo;

    $stmt = $pdo->prepare("
        UPDATE broadcast_queue
        SET
            status=1,
            updated_at=NOW()
        WHERE id=?
    ");

    return $stmt->execute([$queueId]);
}

/*
|--------------------------------------------------------------------------
| MARK QUEUE SENT
|--------------------------------------------------------------------------
*/

function queueSent($queueId, $response = '')
{
    global $pdo;

    $stmt = $pdo->prepare("
        UPDATE broadcast_queue
        SET
            status=2,
            response=?,
            updated_at=NOW()
        WHERE id=?
    ");

    return $stmt->execute([
        $response,
        $queueId
    ]);
}

/*
|--------------------------------------------------------------------------
| MARK QUEUE FAILED
|--------------------------------------------------------------------------
*/

function queueFailed($queueId, $response = '')
{
    global $pdo;

    $stmt = $pdo->prepare("
        UPDATE broadcast_queue
        SET
            status=3,
            attempts=attempts+1,
            response=?,
            updated_at=NOW()
        WHERE id=?
    ");

    return $stmt->execute([
        $response,
        $queueId
    ]);
}

/*
|--------------------------------------------------------------------------
| MARK QUEUE BLOCKED
|--------------------------------------------------------------------------
*/

function queueBlocked($queueId, $response = '')
{
    global $pdo;

    $stmt = $pdo->prepare("
        UPDATE broadcast_queue
        SET
            status=4,
            response=?,
            updated_at=NOW()
        WHERE id=?
    ");

    return $stmt->execute([
        $response,
        $queueId
    ]);
}

/*
|--------------------------------------------------------------------------
| USER INACTIVE
|--------------------------------------------------------------------------
*/

function deactivateUser($chatId)
{
    global $pdo;

    $stmt = $pdo->prepare("
        UPDATE users
        SET is_active=0
        WHERE chat_id=?
    ");

    return $stmt->execute([$chatId]);
}

/*
|--------------------------------------------------------------------------
| ADD LOG
|--------------------------------------------------------------------------
*/

function addLog($broadcastId, $chatId, $status, $response)
{
    global $pdo;

    $stmt = $pdo->prepare("
        INSERT INTO broadcast_logs
        (
            broadcast_id,
            chat_id,
            status,
            telegram_response
        )
        VALUES
        (
            ?,
            ?,
            ?,
            ?
        )
    ");

    return $stmt->execute([
        $broadcastId,
        $chatId,
        $status,
        $response
    ]);
}
/*
|--------------------------------------------------------------------------
| GET PENDING QUEUE
|--------------------------------------------------------------------------
*/

function getPendingQueue($broadcastId, $limit = MULTI_CURL_LIMIT)
{
    global $pdo;

    $stmt = $pdo->prepare("
        SELECT *
        FROM broadcast_queue
        WHERE broadcast_id = ?
        AND status = 0
        ORDER BY id ASC
        LIMIT {$limit}
    ");

    $stmt->execute([$broadcastId]);

    return $stmt->fetchAll();
}

/*
|--------------------------------------------------------------------------
| GET FAILED QUEUE
|--------------------------------------------------------------------------
*/

function getFailedQueue($broadcastId, $limit = 100)
{
    global $pdo;

    $stmt = $pdo->prepare("
        SELECT *
        FROM broadcast_queue
        WHERE broadcast_id = ?
        AND status = 3
        ORDER BY id ASC
        LIMIT {$limit}
    ");

    $stmt->execute([$broadcastId]);

    return $stmt->fetchAll();
}

/*
|--------------------------------------------------------------------------
| RESET FAILED QUEUE
|--------------------------------------------------------------------------
*/

function retryFailedQueue($broadcastId)
{
    global $pdo;

    $stmt = $pdo->prepare("
        UPDATE broadcast_queue
        SET
            status = 0,
            updated_at = NOW()
        WHERE broadcast_id = ?
        AND status = 3
    ");

    return $stmt->execute([$broadcastId]);
}

/*
|--------------------------------------------------------------------------
| RESET BLOCKED QUEUE (OPTIONAL)
|--------------------------------------------------------------------------
*/

function retryBlockedQueue($broadcastId)
{
    global $pdo;

    $stmt = $pdo->prepare("
        UPDATE broadcast_queue
        SET
            status = 0,
            updated_at = NOW()
        WHERE broadcast_id = ?
        AND status = 4
    ");

    return $stmt->execute([$broadcastId]);
}

/*
|--------------------------------------------------------------------------
| GET LATEST BROADCASTS
|--------------------------------------------------------------------------
*/

function latestBroadcasts($limit = 20)
{
    global $pdo;

    $stmt = $pdo->query("
        SELECT *
        FROM broadcasts
        ORDER BY id DESC
        LIMIT {$limit}
    ");

    return $stmt->fetchAll();
}

/*
|--------------------------------------------------------------------------
| DASHBOARD STATS
|--------------------------------------------------------------------------
*/

function dashboardStats()
{
    return [

        'users' => totalUsers(),

        'active_users' => activeUsers(),

        'blocked_users' => blockedUsers(),

        'broadcasts' => totalBroadcasts(),

        'running' => broadcastRunning()

    ];
}

/*
|--------------------------------------------------------------------------
| BROADCAST IS RUNNING
|--------------------------------------------------------------------------
*/

function isBroadcastRunning($broadcastId)
{
    $broadcast = getBroadcast($broadcastId);

    if (!$broadcast) {
        return false;
    }

    return $broadcast['status'] === 'running';
}

/*
|--------------------------------------------------------------------------
| BROADCAST IS PAUSED
|--------------------------------------------------------------------------
*/

function isBroadcastPaused($broadcastId)
{
    $broadcast = getBroadcast($broadcastId);

    if (!$broadcast) {
        return false;
    }

    return $broadcast['status'] === 'paused';
}

/*
|--------------------------------------------------------------------------
| BROADCAST IS STOPPED
|--------------------------------------------------------------------------
*/

function isBroadcastStopped($broadcastId)
{
    $broadcast = getBroadcast($broadcastId);

    if (!$broadcast) {
        return false;
    }

    return $broadcast['status'] === 'stopped';
}

/*
|--------------------------------------------------------------------------
| PAUSE BROADCAST
|--------------------------------------------------------------------------
*/

function pauseBroadcast($broadcastId)
{
    return updateBroadcastStatus(
        $broadcastId,
        'paused'
    );
}

/*
|--------------------------------------------------------------------------
| RESUME BROADCAST
|--------------------------------------------------------------------------
*/

function resumeBroadcast($broadcastId)
{
    return updateBroadcastStatus(
        $broadcastId,
        'running'
    );
}

/*
|--------------------------------------------------------------------------
| STOP BROADCAST
|--------------------------------------------------------------------------
*/

function stopBroadcast($broadcastId)
{
    return updateBroadcastStatus(
        $broadcastId,
        'stopped'
    );
}

/*
|--------------------------------------------------------------------------
| DELETE QUEUE
|--------------------------------------------------------------------------
*/

function deleteQueue($broadcastId)
{
    global $pdo;

    $stmt = $pdo->prepare("
        DELETE FROM broadcast_queue
        WHERE broadcast_id = ?
    ");

    return $stmt->execute([$broadcastId]);
}

/*
|--------------------------------------------------------------------------
| DELETE LOGS
|--------------------------------------------------------------------------
*/

function deleteLogs($broadcastId)
{
    global $pdo;

    $stmt = $pdo->prepare("
        DELETE FROM broadcast_logs
        WHERE broadcast_id = ?
    ");

    return $stmt->execute([$broadcastId]);
}

/*
|--------------------------------------------------------------------------
| AUTO CLEANUP
|--------------------------------------------------------------------------
*/

function cleanupBroadcast($broadcastId)
{
    deleteQueue($broadcastId);

    return true;
}

/*
|--------------------------------------------------------------------------
| MEDIA ARRAY
|--------------------------------------------------------------------------
*/

function mediaArray($json)
{
    if (empty($json)) {
        return [];
    }

    $media = json_decode($json, true);

    if (!is_array($media)) {
        return [];
    }

    return $media;
}

/*
|--------------------------------------------------------------------------
| BUTTON ARRAY
|--------------------------------------------------------------------------
*/

function buttonArray($json)
{
    if (empty($json)) {
        return [];
    }

    $buttons = json_decode($json, true);

    if (!is_array($buttons)) {
        return [];
    }

    return $buttons;
}

/*
|--------------------------------------------------------------------------
| TELEGRAM RESPONSE OK
|--------------------------------------------------------------------------
*/

function telegramSuccess($response)
{
    if (empty($response)) {
        return false;
    }

    $json = json_decode($response, true);

    return isset($json['ok']) && $json['ok'] === true;
}

/*
|--------------------------------------------------------------------------
| TELEGRAM ERROR TEXT
|--------------------------------------------------------------------------
*/

function telegramError($response)
{
    if (empty($response)) {
        return 'Unknown Error';
    }

    $json = json_decode($response, true);

    if (!empty($json['description'])) {
        return $json['description'];
    }

    return 'Telegram Error';
}

/*
|--------------------------------------------------------------------------
| USER BLOCKED CHECK
|--------------------------------------------------------------------------
*/

function isBlockedResponse($response)
{
    $response = strtolower($response);

    $errors = [

        'bot was blocked',

        'user is deactivated',

        'chat not found',

        'forbidden'

    ];

    foreach ($errors as $error) {

        if (strpos($response, $error) !== false) {

            return true;

        }

    }

    return false;
}
/*
|--------------------------------------------------------------------------
| BUILD INLINE KEYBOARD
|--------------------------------------------------------------------------
*/

function buildInlineKeyboard(array $buttons = [])
{
    if (empty($buttons)) {
        return null;
    }

    $keyboard = [];

    foreach ($buttons as $button) {

        if (
            empty($button['text']) ||
            empty($button['url'])
        ) {
            continue;
        }

        $keyboard[][] = [
            'text' => trim($button['text']),
            'url'  => trim($button['url'])
        ];
    }

    if (empty($keyboard)) {
        return null;
    }

    return json_encode([
        'inline_keyboard' => $keyboard
    ], JSON_UNESCAPED_UNICODE);
}

/*
|--------------------------------------------------------------------------
| BUILD MEDIA GROUP
|--------------------------------------------------------------------------
*/

function buildMediaGroup(array $photos = [], $caption = '')
{
    $media = [];

    foreach ($photos as $index => $photo) {

        if (empty($photo)) {
            continue;
        }

        $item = [
            'type'  => 'photo',
            'media' => new CURLFile($photo)
        ];

        if ($index == 0 && !empty($caption)) {
            $item['caption'] = $caption;
            $item['parse_mode'] = 'HTML';
        }

        $media[] = $item;
    }

    return $media;
}

/*
|--------------------------------------------------------------------------
| PHOTO PATH
|--------------------------------------------------------------------------
*/

function photoPath($file)
{
    return PHOTO_PATH . basename($file);
}

/*
|--------------------------------------------------------------------------
| VIDEO PATH
|--------------------------------------------------------------------------
*/

function videoPath($file)
{
    return VIDEO_PATH . basename($file);
}

/*
|--------------------------------------------------------------------------
| DOCUMENT PATH
|--------------------------------------------------------------------------
*/

function documentPath($file)
{
    return DOCUMENT_PATH . basename($file);
}

/*
|--------------------------------------------------------------------------
| VALIDATE BROADCAST
|--------------------------------------------------------------------------
*/

function validateBroadcast(array $data)
{
    $errors = [];

    if (empty(trim($data['title'] ?? ''))) {
        $errors[] = 'Broadcast title is required.';
    }

    if (empty(trim($data['type'] ?? ''))) {
        $errors[] = 'Broadcast type is required.';
    }

    $allowed = [
        'text',
        'photo',
        'album',
        'video',
        'document'
    ];

    if (!in_array($data['type'], $allowed)) {
        $errors[] = 'Invalid broadcast type.';
    }

    if (
        empty(trim($data['message'] ?? ''))
        &&
        $data['type'] == 'text'
    ) {
        $errors[] = 'Message cannot be empty.';
    }

    return $errors;
}

/*
|--------------------------------------------------------------------------
| LOCK FILE
|--------------------------------------------------------------------------
*/

function workerLockFile()
{
    return sys_get_temp_dir() . '/telegram_worker.lock';
}

/*
|--------------------------------------------------------------------------
| WORKER LOCK
|--------------------------------------------------------------------------
*/

function workerLocked()
{
    return file_exists(workerLockFile());
}

/*
|--------------------------------------------------------------------------
| CREATE LOCK
|--------------------------------------------------------------------------
*/

function createWorkerLock()
{
    file_put_contents(
        workerLockFile(),
        time()
    );
}

/*
|--------------------------------------------------------------------------
| REMOVE LOCK
|--------------------------------------------------------------------------
*/

function removeWorkerLock()
{
    if (workerLocked()) {
        unlink(workerLockFile());
    }
}

/*
|--------------------------------------------------------------------------
| FORMAT BYTES
|--------------------------------------------------------------------------
*/

function formatBytes($bytes)
{
    $units = ['B','KB','MB','GB','TB'];

    $i = 0;

    while ($bytes >= 1024 && $i < count($units)-1) {

        $bytes /= 1024;

        $i++;
    }

    return round($bytes,2).' '.$units[$i];
}

/*
|--------------------------------------------------------------------------
| MEMORY LIMIT
|--------------------------------------------------------------------------
*/

function memoryLimit()
{
    return ini_get('memory_limit');
}

/*
|--------------------------------------------------------------------------
| EXECUTION LIMIT
|--------------------------------------------------------------------------
*/

function executionLimit()
{
    return ini_get('max_execution_time');
}

/*
|--------------------------------------------------------------------------
| SERVER LOAD
|--------------------------------------------------------------------------
*/

function serverLoad()
{
    if (!function_exists('sys_getloadavg')) {
        return '-';
    }

    $load = sys_getloadavg();

    return round($load[0],2);
}

/*
|--------------------------------------------------------------------------
| IS JSON
|--------------------------------------------------------------------------
*/

function isJson($string)
{
    json_decode($string);

    return json_last_error() === JSON_ERROR_NONE;
}

/*
|--------------------------------------------------------------------------
| SAFE JSON
|--------------------------------------------------------------------------
*/

function safeJsonDecode($json)
{
    if (!isJson($json)) {
        return [];
    }

    return json_decode($json,true);
}

/*
|--------------------------------------------------------------------------
| TELEGRAM FILE EXISTS
|--------------------------------------------------------------------------
*/

function mediaExists($path)
{
    return file_exists($path);
}

/*
|--------------------------------------------------------------------------
| DELETE FILE
|--------------------------------------------------------------------------
*/

function deleteMedia($path)
{
    if (file_exists($path)) {
        unlink($path);
    }
}

/*
|--------------------------------------------------------------------------
| DELETE MULTIPLE FILES
|--------------------------------------------------------------------------
*/

function deleteFiles(array $files)
{
    foreach ($files as $file) {

        deleteMedia($file);

    }
}

/*
|--------------------------------------------------------------------------
| MICROTIME START
|--------------------------------------------------------------------------
*/

function timerStart()
{
    return microtime(true);
}

/*
|--------------------------------------------------------------------------
| MICROTIME END
|--------------------------------------------------------------------------
*/

function timerEnd($start)
{
    return round(
        microtime(true) - $start,
        3
    );
}

/*
|--------------------------------------------------------------------------
| PROJECT VERSION
|--------------------------------------------------------------------------
*/

function version()
{
    return '1.0.0';
}

/*
|--------------------------------------------------------------------------
| APPLICATION INFO
|--------------------------------------------------------------------------
*/

function appInfo()
{
    return [

        'name' => APP_NAME,

        'version' => version(),

        'php' => PHP_VERSION,

        'memory_limit' => memoryLimit(),

        'execution_time' => executionLimit(),

        'server_load' => serverLoad()

    ];
}