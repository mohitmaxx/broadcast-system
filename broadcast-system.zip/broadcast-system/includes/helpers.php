<?php

if (!defined('APP_START')) {
    exit('No direct script access allowed');
}

/*
|--------------------------------------------------------------------------
| ESCAPE HTML
|--------------------------------------------------------------------------
*/

function e($string)
{
    return htmlspecialchars((string)$string, ENT_QUOTES, 'UTF-8');
}

/*
|--------------------------------------------------------------------------
| REDIRECT
|--------------------------------------------------------------------------
*/

function redirect($url)
{
    header("Location: {$url}");
    exit;
}

/*
|--------------------------------------------------------------------------
| JSON RESPONSE
|--------------------------------------------------------------------------
*/

function jsonResponse($status, $message = '', $data = [])
{
    header('Content-Type: application/json');

    echo json_encode([
        'status'  => $status,
        'message' => $message,
        'data'    => $data
    ]);

    exit;
}

/*
|--------------------------------------------------------------------------
| SUCCESS MESSAGE
|--------------------------------------------------------------------------
*/

function success($message)
{
    $_SESSION['success'] = $message;
}

/*
|--------------------------------------------------------------------------
| ERROR MESSAGE
|--------------------------------------------------------------------------
*/

function error($message)
{
    $_SESSION['error'] = $message;
}

/*
|--------------------------------------------------------------------------
| GET SUCCESS
|--------------------------------------------------------------------------
*/

function getSuccess()
{
    if (!empty($_SESSION['success'])) {

        $msg = $_SESSION['success'];

        unset($_SESSION['success']);

        return $msg;
    }

    return '';
}

/*
|--------------------------------------------------------------------------
| GET ERROR
|--------------------------------------------------------------------------
*/

function getError()
{
    if (!empty($_SESSION['error'])) {

        $msg = $_SESSION['error'];

        unset($_SESSION['error']);

        return $msg;
    }

    return '';
}

/*
|--------------------------------------------------------------------------
| FORMAT NUMBER
|--------------------------------------------------------------------------
*/

function number($num)
{
    return number_format((int)$num);
}

/*
|--------------------------------------------------------------------------
| FORMAT DATE
|--------------------------------------------------------------------------
*/

function formatDate($date)
{
    if (empty($date)) {
        return '-';
    }

    return date('d M Y h:i A', strtotime($date));
}

/*
|--------------------------------------------------------------------------
| TIME AGO
|--------------------------------------------------------------------------
*/

function timeAgo($datetime)
{
    if (!$datetime) {
        return '-';
    }

    $time = time() - strtotime($datetime);

    if ($time < 60) {
        return $time . " sec ago";
    }

    if ($time < 3600) {
        return floor($time / 60) . " min ago";
    }

    if ($time < 86400) {
        return floor($time / 3600) . " hrs ago";
    }

    if ($time < 2592000) {
        return floor($time / 86400) . " days ago";
    }

    return date('d M Y', strtotime($datetime));
}

/*
|--------------------------------------------------------------------------
| STATUS BADGE
|--------------------------------------------------------------------------
*/

function badge($status)
{
    switch ($status) {

        case 'pending':
            return '<span class="badge bg-secondary">Pending</span>';

        case 'running':
            return '<span class="badge bg-primary">Running</span>';

        case 'paused':
            return '<span class="badge bg-warning text-dark">Paused</span>';

        case 'completed':
            return '<span class="badge bg-success">Completed</span>';

        case 'stopped':
            return '<span class="badge bg-danger">Stopped</span>';

        default:
            return '<span class="badge bg-dark">'.$status.'</span>';
    }
}

/*
|--------------------------------------------------------------------------
| FILE EXTENSION
|--------------------------------------------------------------------------
*/

function extension($filename)
{
    return strtolower(pathinfo($filename, PATHINFO_EXTENSION));
}

/*
|--------------------------------------------------------------------------
| RANDOM STRING
|--------------------------------------------------------------------------
*/

function randomString($length = 40)
{
    return bin2hex(random_bytes($length / 2));
}

/*
|--------------------------------------------------------------------------
| GENERATE FILE NAME
|--------------------------------------------------------------------------
*/

function generateFileName($name)
{
    return time() . "_" . randomString(10) . "." . extension($name);
}

/*
|--------------------------------------------------------------------------
| CREATE DIRECTORY
|--------------------------------------------------------------------------
*/

function makeDirectory($path)
{
    if (!is_dir($path)) {

        mkdir($path, 0777, true);

    }
}

/*
|--------------------------------------------------------------------------
| IS POST
|--------------------------------------------------------------------------
*/

function isPost()
{
    return $_SERVER['REQUEST_METHOD'] === 'POST';
}

/*
|--------------------------------------------------------------------------
| IS GET
|--------------------------------------------------------------------------
*/

function isGet()
{
    return $_SERVER['REQUEST_METHOD'] === 'GET';
}

/*
|--------------------------------------------------------------------------
| CLIENT IP
|--------------------------------------------------------------------------
*/

function clientIP()
{
    if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
        return $_SERVER['HTTP_CF_CONNECTING_IP'];
    }

    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        return trim(explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0]);
    }

    return $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN';
}

/*
|--------------------------------------------------------------------------
| MEMORY USAGE
|--------------------------------------------------------------------------
*/

function memoryUsage()
{
    return round(memory_get_usage(true) / 1024 / 1024, 2) . " MB";
}

/*
|--------------------------------------------------------------------------
| EXECUTION TIME
|--------------------------------------------------------------------------
*/

function executionTime($start)
{
    return round(microtime(true) - $start, 3);
}

/*
|--------------------------------------------------------------------------
| ARRAY TO JSON
|--------------------------------------------------------------------------
*/

function toJson($array)
{
    return json_encode($array, JSON_UNESCAPED_UNICODE);
}

/*
|--------------------------------------------------------------------------
| JSON TO ARRAY
|--------------------------------------------------------------------------
*/

function fromJson($json)
{
    if (empty($json)) {
        return [];
    }

    return json_decode($json, true);
}

/*
|--------------------------------------------------------------------------
| LOG FILE
|--------------------------------------------------------------------------
*/

function writeLog($file, $text)
{
    file_put_contents(
        $file,
        "[" . date('Y-m-d H:i:s') . "] " . $text . PHP_EOL,
        FILE_APPEND
    );
}