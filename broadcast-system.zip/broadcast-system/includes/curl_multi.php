<?php

if (!defined('APP_START')) {
    exit('No direct script access allowed');
}

/*
|--------------------------------------------------------------------------
| CURL DEFAULT OPTIONS
|--------------------------------------------------------------------------
*/

function curlDefaults()
{
    return [

        CURLOPT_RETURNTRANSFER => true,

        CURLOPT_CONNECTTIMEOUT => 20,

        CURLOPT_TIMEOUT => 90,

        CURLOPT_SSL_VERIFYPEER => false,

        CURLOPT_SSL_VERIFYHOST => false,

        CURLOPT_USERAGENT => 'TelegramBroadcast/1.0',

        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1

    ];
}

/*
|--------------------------------------------------------------------------
| CREATE CURL HANDLE
|--------------------------------------------------------------------------
*/

function createCurlHandle($method, array $postFields = [])
{
    $ch = curl_init();

    curl_setopt_array($ch, curlDefaults());

    curl_setopt($ch, CURLOPT_URL, TELEGRAM_API . $method);

    curl_setopt($ch, CURLOPT_POST, true);

    curl_setopt($ch, CURLOPT_POSTFIELDS, $postFields);

    return $ch;
}

/*
|--------------------------------------------------------------------------
| SIMPLE TELEGRAM REQUEST
|--------------------------------------------------------------------------
*/

function telegramRequestRaw($method, array $postFields = [])
{
    $ch = createCurlHandle($method, $postFields);

    $response = curl_exec($ch);

    $error = curl_error($ch);

    $http = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    curl_close($ch);

    return [

        'response' => $response,

        'error' => $error,

        'http_code' => $http

    ];
}

/*
|--------------------------------------------------------------------------
| SEND MESSAGE
|--------------------------------------------------------------------------
*/

function tgSendMessage(
    $chatId,
    $message,
    $keyboard = null
)
{
    $post = [

        'chat_id' => $chatId,

        'text' => $message,

        'parse_mode' => 'HTML',

        'disable_web_page_preview' => false

    ];

    if (!empty($keyboard)) {

        $post['reply_markup'] = $keyboard;

    }

    return telegramRequestRaw(
        'sendMessage',
        $post
    );
}

/*
|--------------------------------------------------------------------------
| SEND PHOTO
|--------------------------------------------------------------------------
*/

function tgSendPhoto(
    $chatId,
    $photo,
    $caption = '',
    $keyboard = null
)
{
    $post = [

        'chat_id' => $chatId,

        'photo' => new CURLFile($photo),

        'caption' => $caption,

        'parse_mode' => 'HTML'

    ];

    if (!empty($keyboard)) {

        $post['reply_markup'] = $keyboard;

    }

    return telegramRequestRaw(
        'sendPhoto',
        $post
    );
}

/*
|--------------------------------------------------------------------------
| SEND VIDEO
|--------------------------------------------------------------------------
*/

function tgSendVideo(
    $chatId,
    $video,
    $caption = '',
    $keyboard = null
)
{
    $post = [

        'chat_id' => $chatId,

        'video' => new CURLFile($video),

        'caption' => $caption,

        'parse_mode' => 'HTML',

        'supports_streaming' => true

    ];

    if (!empty($keyboard)) {

        $post['reply_markup'] = $keyboard;

    }

    return telegramRequestRaw(
        'sendVideo',
        $post
    );
}

/*
|--------------------------------------------------------------------------
| SEND DOCUMENT
|--------------------------------------------------------------------------
*/

function tgSendDocument(
    $chatId,
    $document,
    $caption = '',
    $keyboard = null
)
{
    $post = [

        'chat_id' => $chatId,

        'document' => new CURLFile($document),

        'caption' => $caption,

        'parse_mode' => 'HTML'

    ];

    if (!empty($keyboard)) {

        $post['reply_markup'] = $keyboard;

    }

    return telegramRequestRaw(
        'sendDocument',
        $post
    );
}

/*
|--------------------------------------------------------------------------
| CURL RESPONSE JSON
|--------------------------------------------------------------------------
*/

function curlJson($response)
{
    if (empty($response)) {

        return [];

    }

    $json = json_decode($response, true);

    if (!is_array($json)) {

        return [];

    }

    return $json;
}

/*
|--------------------------------------------------------------------------
| CURL SUCCESS
|--------------------------------------------------------------------------
*/

function curlSuccess(array $result)
{
    if (!empty($result['error'])) {

        return false;

    }

    if (($result['http_code'] ?? 0) != 200) {

        return false;

    }

    $json = curlJson(
        $result['response']
    );

    return !empty($json['ok']);
}

/*
|--------------------------------------------------------------------------
| CURL ERROR
|--------------------------------------------------------------------------
*/

function curlErrorMessage(array $result)
{
    if (!empty($result['error'])) {

        return $result['error'];

    }

    $json = curlJson(
        $result['response']
    );

    if (!empty($json['description'])) {

        return $json['description'];

    }

    return 'Unknown Error';
}
/*
|--------------------------------------------------------------------------
| CREATE MULTI HANDLE
|--------------------------------------------------------------------------
*/

function multiHandle()
{
    return curl_multi_init();
}

/*
|--------------------------------------------------------------------------
| CLOSE MULTI HANDLE
|--------------------------------------------------------------------------
*/

function closeMultiHandle($multi)
{
    curl_multi_close($multi);
}

/*
|--------------------------------------------------------------------------
| ADD HANDLE
|--------------------------------------------------------------------------
*/

function addCurlHandle($multi, $ch)
{
    curl_multi_add_handle($multi, $ch);
}

/*
|--------------------------------------------------------------------------
| REMOVE HANDLE
|--------------------------------------------------------------------------
*/

function removeCurlHandle($multi, $ch)
{
    curl_multi_remove_handle($multi, $ch);

    curl_close($ch);
}

/*
|--------------------------------------------------------------------------
| EXECUTE MULTI CURL
|--------------------------------------------------------------------------
*/

function executeMultiCurl($multi)
{
    $running = null;

    do {

        $status = curl_multi_exec(
            $multi,
            $running
        );

        if ($running) {

            curl_multi_select(
                $multi,
                1
            );

        }

    } while (
        $running &&
        $status == CURLM_OK
    );
}

/*
|--------------------------------------------------------------------------
| GET HANDLE RESPONSE
|--------------------------------------------------------------------------
*/

function handleResponse($ch)
{
    return [

        'response' => curl_multi_getcontent($ch),

        'error' => curl_error($ch),

        'http_code' => curl_getinfo(
            $ch,
            CURLINFO_HTTP_CODE
        )

    ];
}

/*
|--------------------------------------------------------------------------
| FLOOD WAIT
|--------------------------------------------------------------------------
*/

function floodWaitSeconds($response)
{
    $json = curlJson($response);

    if (
        empty($json['parameters']['retry_after'])
    ) {

        return 0;

    }

    return (int)$json['parameters']['retry_after'];
}

/*
|--------------------------------------------------------------------------
| IS FLOOD WAIT
|--------------------------------------------------------------------------
*/

function isFloodWait($response)
{
    $json = curlJson($response);

    if (empty($json)) {

        return false;

    }

    if (
        !empty($json['error_code']) &&
        $json['error_code'] == 429
    ) {

        return true;

    }

    return false;
}

/*
|--------------------------------------------------------------------------
| CREATE SEND HANDLE
|--------------------------------------------------------------------------
*/

function createSendHandle(
    $method,
    array $post
)
{
    return createCurlHandle(
        $method,
        $post
    );
}

/*
|--------------------------------------------------------------------------
| RESPONSE OK
|--------------------------------------------------------------------------
*/

function responseOk($response)
{
    $json = curlJson($response);

    return (
        !empty($json['ok']) &&
        $json['ok'] === true
    );
}

/*
|--------------------------------------------------------------------------
| TELEGRAM MESSAGE ID
|--------------------------------------------------------------------------
*/

function telegramMessageId($response)
{
    $json = curlJson($response);

    if (
        empty($json['result']['message_id'])
    ) {

        return 0;

    }

    return (int)
        $json['result']['message_id'];
}

/*
|--------------------------------------------------------------------------
| TELEGRAM CHAT ID
|--------------------------------------------------------------------------
*/

function telegramChatId($response)
{
    $json = curlJson($response);

    if (
        empty($json['result']['chat']['id'])
    ) {

        return 0;

    }

    return (int)
        $json['result']['chat']['id'];
}

/*
|--------------------------------------------------------------------------
| CURL INFO
|--------------------------------------------------------------------------
*/

function curlStatistics($ch)
{
    return [

        'total_time' => curl_getinfo(
            $ch,
            CURLINFO_TOTAL_TIME
        ),

        'namelookup_time' => curl_getinfo(
            $ch,
            CURLINFO_NAMELOOKUP_TIME
        ),

        'connect_time' => curl_getinfo(
            $ch,
            CURLINFO_CONNECT_TIME
        ),

        'starttransfer_time' => curl_getinfo(
            $ch,
            CURLINFO_STARTTRANSFER_TIME
        ),

        'http_code' => curl_getinfo(
            $ch,
            CURLINFO_HTTP_CODE
        )

    ];
}

/*
|--------------------------------------------------------------------------
| NETWORK ERROR
|--------------------------------------------------------------------------
*/

function networkError($error)
{
    if (empty($error)) {

        return false;

    }

    return true;
}
/*
|--------------------------------------------------------------------------
| BUILD TELEGRAM REQUEST
|--------------------------------------------------------------------------
*/

function buildTelegramRequest($broadcast, $chatId)
{
    $keyboard = buildInlineKeyboard(
        buttonArray($broadcast['buttons'])
    );

    switch ($broadcast['type']) {

        case 'text':

            return [

                'method' => 'sendMessage',

                'post' => [

                    'chat_id' => $chatId,

                    'text' => $broadcast['message'],

                    'parse_mode' => 'HTML',

                    'disable_web_page_preview' => false,

                    'reply_markup' => $keyboard

                ]

            ];

        case 'photo':

            return [

                'method' => 'sendPhoto',

                'post' => [

                    'chat_id' => $chatId,

                    'photo' => new CURLFile(
                        photoPath($broadcast['media'])
                    ),

                    'caption' => $broadcast['message'],

                    'parse_mode' => 'HTML',

                    'reply_markup' => $keyboard

                ]

            ];

        case 'video':

            return [

                'method' => 'sendVideo',

                'post' => [

                    'chat_id' => $chatId,

                    'video' => new CURLFile(
                        videoPath($broadcast['media'])
                    ),

                    'caption' => $broadcast['message'],

                    'parse_mode' => 'HTML',

                    'supports_streaming' => true,

                    'reply_markup' => $keyboard

                ]

            ];

        case 'document':

            return [

                'method' => 'sendDocument',

                'post' => [

                    'chat_id' => $chatId,

                    'document' => new CURLFile(
                        documentPath($broadcast['media'])
                    ),

                    'caption' => $broadcast['message'],

                    'parse_mode' => 'HTML',

                    'reply_markup' => $keyboard

                ]

            ];

        default:

            return false;

    }

}

/*
|--------------------------------------------------------------------------
| CREATE HANDLE FROM BROADCAST
|--------------------------------------------------------------------------
*/

function createBroadcastHandle($broadcast, $chatId)
{
    $request = buildTelegramRequest(
        $broadcast,
        $chatId
    );

    if (!$request) {
        return false;
    }

    return createCurlHandle(
        $request['method'],
        $request['post']
    );
}

/*
|--------------------------------------------------------------------------
| MULTI HANDLE COLLECTION
|--------------------------------------------------------------------------
*/

function createBroadcastHandles(
    $broadcast,
    array $queue
)
{
    $handles = [];

    foreach ($queue as $item) {

        $handle = createBroadcastHandle(

            $broadcast,

            $item['chat_id']

        );

        if ($handle) {

            $handles[] = [

                'queue' => $item,

                'handle' => $handle

            ];

        }

    }

    return $handles;
}

/*
|--------------------------------------------------------------------------
| EXECUTE HANDLE COLLECTION
|--------------------------------------------------------------------------
*/

function executeHandleCollection(array $handles)
{
    $multi = multiHandle();

    foreach ($handles as $item) {

        addCurlHandle(

            $multi,

            $item['handle']

        );

    }

    executeMultiCurl($multi);

    $results = [];

    foreach ($handles as $item) {

        $results[] = [

            'queue' => $item['queue'],

            'result' => handleResponse(
                $item['handle']
            )

        ];

        removeCurlHandle(

            $multi,

            $item['handle']

        );

    }

    closeMultiHandle($multi);

    return $results;
}

/*
|--------------------------------------------------------------------------
| PARSE MULTI RESULT
|--------------------------------------------------------------------------
*/

function parseMultiResult($result)
{
    return [

        'success' => curlSuccess($result),

        'response' => $result['response'],

        'error' => curlErrorMessage($result),

        'http' => $result['http_code']

    ];
}

/*
|--------------------------------------------------------------------------
| TELEGRAM RETRY
|--------------------------------------------------------------------------
*/

function shouldRetry($result)
{
    if (!empty($result['error'])) {

        return true;

    }

    if (
        $result['http_code'] >= 500
    ) {

        return true;

    }

    if (
        isFloodWait(
            $result['response']
        )
    ) {

        return true;

    }

    return false;
}
/*
|--------------------------------------------------------------------------
| BUILD MEDIA GROUP
|--------------------------------------------------------------------------
*/

function buildMediaGroupPayload(array $photos, $caption = '')
{
    $media = [];

    foreach ($photos as $index => $photo) {

        $item = [
            'type'  => 'photo',
            'media' => 'attach://photo' . $index
        ];

        if ($index === 0 && $caption !== '') {
            $item['caption'] = $caption;
            $item['parse_mode'] = 'HTML';
        }

        $media[] = $item;
    }

    return $media;
}

/*
|--------------------------------------------------------------------------
| SEND MEDIA GROUP
|--------------------------------------------------------------------------
*/

function tgSendMediaGroup($chatId, array $photos, $caption = '')
{
    $post = [
        'chat_id' => $chatId
    ];

    $media = buildMediaGroupPayload($photos, $caption);

    foreach ($photos as $index => $file) {
        $post['photo' . $index] = new CURLFile($file);
    }

    $post['media'] = json_encode($media);

    return telegramRequestRaw(
        'sendMediaGroup',
        $post
    );
}

/*
|--------------------------------------------------------------------------
| RETRY DELAY
|--------------------------------------------------------------------------
*/

function retryDelay(array $result)
{
    if (isFloodWait($result['response'])) {

        $wait = floodWaitSeconds(
            $result['response']
        );

        if ($wait > 0) {
            return $wait;
        }
    }

    return 5;
}

/*
|--------------------------------------------------------------------------
| EXECUTE BROADCAST BATCH
|--------------------------------------------------------------------------
*/

function executeBroadcastBatch($broadcast, array $queue)
{
    $handles = createBroadcastHandles(
        $broadcast,
        $queue
    );

    return executeHandleCollection(
        $handles
    );
}

/*
|--------------------------------------------------------------------------
| EXECUTE ALBUM BATCH
|--------------------------------------------------------------------------
*/

function executeAlbumBatch($broadcast, array $queue)
{
    $results = [];

    $photos = mediaFiles($broadcast['media']);

    $paths = [];

    foreach ($photos as $photo) {
        $paths[] = PHOTO_PATH . $photo;
    }

    foreach ($queue as $item) {

        $result = tgSendMediaGroup(
            $item['chat_id'],
            $paths,
            $broadcast['message']
        );

        $results[] = [
            'queue'  => $item,
            'result' => $result
        ];
    }

    return $results;
}

/*
|--------------------------------------------------------------------------
| EXECUTE BY TYPE
|--------------------------------------------------------------------------
*/

function executeQueueBatch($broadcast, array $queue)
{
    if ($broadcast['type'] === 'album') {
        return executeAlbumBatch(
            $broadcast,
            $queue
        );
    }

    return executeBroadcastBatch(
        $broadcast,
        $queue
    );
}

/*
|--------------------------------------------------------------------------
| HAS CURL ERROR
|--------------------------------------------------------------------------
*/

function hasCurlError(array $result)
{
    return !empty($result['error']);
}

/*
|--------------------------------------------------------------------------
| IS TELEGRAM SUCCESS
|--------------------------------------------------------------------------
*/

function isTelegramSuccess(array $result)
{
    return curlSuccess($result);
}

/*
|--------------------------------------------------------------------------
| TELEGRAM DESCRIPTION
|--------------------------------------------------------------------------
*/

function telegramDescription(array $result)
{
    $json = curlJson($result['response']);

    return $json['description'] ?? '';
}

/*
|--------------------------------------------------------------------------
| TELEGRAM ERROR CODE
|--------------------------------------------------------------------------
*/

function telegramErrorCode(array $result)
{
    $json = curlJson($result['response']);

    return (int)($json['error_code'] ?? 0);
}

/*
|--------------------------------------------------------------------------
| NEED RETRY
|--------------------------------------------------------------------------
*/

function needRetry(array $result)
{
    if (hasCurlError($result)) {
        return true;
    }

    $code = telegramErrorCode($result);

    if ($code == 429) {
        return true;
    }

    if ($code >= 500) {
        return true;
    }

    return false;
}