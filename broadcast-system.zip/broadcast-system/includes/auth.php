<?php

if (!defined('APP_START')) {
    exit('No direct script access allowed');
}

/*
|--------------------------------------------------------------------------
| LOGIN SESSION KEY
|--------------------------------------------------------------------------
*/

define('ADMIN_SESSION_KEY', 'broadcast_admin');

/*
|--------------------------------------------------------------------------
| CHECK LOGIN
|--------------------------------------------------------------------------
*/

function isLoggedIn()
{
    return (
        isset($_SESSION[ADMIN_SESSION_KEY]) &&
        !empty($_SESSION[ADMIN_SESSION_KEY]['id'])
    );
}

/*
|--------------------------------------------------------------------------
| CURRENT ADMIN
|--------------------------------------------------------------------------
*/

function currentAdmin()
{
    if (!isLoggedIn()) {
        return null;
    }

    return $_SESSION[ADMIN_SESSION_KEY];
}

/*
|--------------------------------------------------------------------------
| ADMIN ID
|--------------------------------------------------------------------------
*/

function adminId()
{
    $admin = currentAdmin();

    return $admin['id'] ?? 0;
}

/*
|--------------------------------------------------------------------------
| ADMIN USERNAME
|--------------------------------------------------------------------------
*/

function adminUsername()
{
    $admin = currentAdmin();

    return $admin['username'] ?? '';
}

/*
|--------------------------------------------------------------------------
| LOGIN
|--------------------------------------------------------------------------
*/

function login($username, $password)
{
    global $pdo;

    $stmt = $pdo->prepare("
        SELECT *
        FROM admins
        WHERE username = ?
        LIMIT 1
    ");

    $stmt->execute([
        trim($username)
    ]);

    $admin = $stmt->fetch();

    if (!$admin) {
        return false;
    }

    if (!password_verify($password, $admin['password'])) {
        return false;
    }

    $_SESSION[ADMIN_SESSION_KEY] = [

        'id' => $admin['id'],

        'username' => $admin['username'],

        'login_time' => time(),

        'ip' => clientIP()

    ];

    session_regenerate_id(true);

    return true;
}

/*
|--------------------------------------------------------------------------
| LOGOUT
|--------------------------------------------------------------------------
*/

function logout()
{
    unset($_SESSION[ADMIN_SESSION_KEY]);

    session_destroy();

    return true;
}

/*
|--------------------------------------------------------------------------
| REQUIRE LOGIN
|--------------------------------------------------------------------------
*/

function requireLogin()
{
    if (!isLoggedIn()) {

        redirect('login.php');

    }
}

/*
|--------------------------------------------------------------------------
| REQUIRE GUEST
|--------------------------------------------------------------------------
*/

function requireGuest()
{
    if (isLoggedIn()) {

        redirect('index.php');

    }
}

/*
|--------------------------------------------------------------------------
| SESSION TIMEOUT
|--------------------------------------------------------------------------
*/

function checkSessionTimeout($minutes = 720)
{
    if (!isLoggedIn()) {
        return;
    }

    if (empty($_SESSION[ADMIN_SESSION_KEY]['login_time'])) {
        logout();
        redirect('login.php');
    }

    $expire = $minutes * 60;

    if (
        time() -
        $_SESSION[ADMIN_SESSION_KEY]['login_time']
        >
        $expire
    ) {

        logout();

        redirect('login.php');

    }
}

/*
|--------------------------------------------------------------------------
| REFRESH SESSION
|--------------------------------------------------------------------------
*/

function refreshSession()
{
    if (!isLoggedIn()) {
        return;
    }

    $_SESSION[ADMIN_SESSION_KEY]['login_time'] = time();
}

/*
|--------------------------------------------------------------------------
| LOGIN PAGE
|--------------------------------------------------------------------------
*/

function loginPage()
{
    requireGuest();
}

/*
|--------------------------------------------------------------------------
| PROTECTED PAGE
|--------------------------------------------------------------------------
*/

function protectedPage()
{
    requireLogin();

    checkSessionTimeout();

    refreshSession();
}