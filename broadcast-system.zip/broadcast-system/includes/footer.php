<?php

if (!defined('APP_START')) {
    exit('No direct script access allowed');
}

?>

</main>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script>

const csrfToken = document.querySelector(
    'meta[name="csrf-token"]'
)?.content || '';

function showLoader()
{
    const loader =
        document.getElementById(
            'ajaxLoading'
        );

    if (loader) {

        loader.classList.remove(
            'd-none'
        );

    }
}

function hideLoader()
{
    const loader =
        document.getElementById(
            'ajaxLoading'
        );

    if (loader) {

        loader.classList.add(
            'd-none'
        );

    }
}

function post(url, data = {})
{
    showLoader();

    data.csrf_token = csrfToken;

    return fetch(url, {

        method: 'POST',

        headers: {

            'Content-Type':
                'application/json'

        },

        body: JSON.stringify(data)

    })
    .then(res => res.json())
    .finally(() => {

        hideLoader();

    });
}

function get(url)
{
    showLoader();

    return fetch(url)
    .then(res => res.json())
    .finally(() => {

        hideLoader();

    });
}

function toast(message, type='success')
{
    const container =
        document.getElementById(
            'toastContainer'
        );

    const id =
        'toast_' + Date.now();

    container.insertAdjacentHTML(

        'beforeend',

`
<div
class="toast align-items-center
text-bg-${type}
border-0"
id="${id}">

<div class="d-flex">

<div class="toast-body">

${message}

</div>

<button
class="btn-close
btn-close-white
me-2
m-auto"
data-bs-dismiss="toast">

</button>

</div>

</div>
`

    );

    const el =
        document.getElementById(id);

    const bs =
        new bootstrap.Toast(el);

    bs.show();

    el.addEventListener(
        'hidden.bs.toast',
        () => el.remove()
    );
}

function showModal(content, title = '')
{
    const modalElement =
        document.getElementById('globalModal');

    if (!modalElement) {
        return;
    }

    if (title !== '') {

        const titleElement =
            modalElement.querySelector(
                '.modal-title'
            );

        if (titleElement) {
            titleElement.textContent = title;
        }
    }

    const body =
        document.getElementById(
            'globalModalBody'
        );

    if (body) {
        body.innerHTML = content;
    }

    bootstrap.Modal
        .getOrCreateInstance(
            modalElement
        )
        .show();
}

function hideModal()
{
    const modalElement =
        document.getElementById(
            'globalModal'
        );

    if (!modalElement) {
        return;
    }

    bootstrap.Modal
        .getOrCreateInstance(
            modalElement
        )
        .hide();
}

function confirmAction(
    message = 'Are you sure?'
)
{
    return window.confirm(message);
}

window.addEventListener(
    'DOMContentLoaded',
    function () {

        document
            .querySelectorAll('.alert')
            .forEach(function(alert){

                setTimeout(function(){

                    bootstrap.Alert
                        .getOrCreateInstance(alert)
                        .close();

                },5000);

            });

    }
);

window.addEventListener(
    'keydown',
    function(e){

        if(
            e.key === 'Escape'
        ){
            hideModal();
        }

    }
);

window.addEventListener(
    'unhandledrejection',
    function(){

        hideLoader();

        toast(
            'Unexpected error occurred.',
            'danger'
        );

    }
);

window.addEventListener(
    'error',
    function(){

        hideLoader();

    }
);

</script>

</body>

</html>