<?php

if (!defined('APP_START')) {
    exit('No direct script access allowed');
}

/*
|--------------------------------------------------------------------------
| CONFIG
|--------------------------------------------------------------------------
*/

define('CSRF_SESSION_KEY', '_csrf_token');
define('CSRF_TIME_KEY', '_csrf_time');
define('CSRF_EXPIRE', 3600); // 1 Hour

/*
|--------------------------------------------------------------------------
| GENERATE TOKEN
|--------------------------------------------------------------------------
*/

function csrfToken()
{
    if (
        empty($_SESSION[CSRF_SESSION_KEY]) ||
        empty($_SESSION[CSRF_TIME_KEY]) ||
        (time() - $_SESSION[CSRF_TIME_KEY]) > CSRF_EXPIRE
    ) {

        $_SESSION[CSRF_SESSION_KEY] = bin2hex(random_bytes(32));

        $_SESSION[CSRF_TIME_KEY] = time();
    }

    return $_SESSION[CSRF_SESSION_KEY];
}

/*
|--------------------------------------------------------------------------
| HIDDEN INPUT
|--------------------------------------------------------------------------
*/

function csrfField()
{
    return '<input type="hidden" name="_token" value="' .
        csrfToken() .
        '">';
}

/*
|--------------------------------------------------------------------------
| VERIFY TOKEN
|--------------------------------------------------------------------------
*/

function verifyCsrf($token = null)
{
    if ($token === null) {
        $token = $_POST['_token'] ?? '';
    }

    if (empty($token)) {
        return false;
    }

    if (empty($_SESSION[CSRF_SESSION_KEY])) {
        return false;
    }

    return hash_equals(
        $_SESSION[CSRF_SESSION_KEY],
        $token
    );
}

/*
|--------------------------------------------------------------------------
| REQUIRE VALID TOKEN
|--------------------------------------------------------------------------
*/

function requireCsrf()
{
    if (!verifyCsrf()) {

        http_response_code(403);

        exit('Invalid CSRF Token');
    }
}

/*
|--------------------------------------------------------------------------
| REGENERATE TOKEN
|--------------------------------------------------------------------------
*/

function regenerateCsrf()
{
    unset($_SESSION[CSRF_SESSION_KEY]);

    unset($_SESSION[CSRF_TIME_KEY]);

    csrfToken();
}

/*
|--------------------------------------------------------------------------
| DESTROY TOKEN
|--------------------------------------------------------------------------
*/

function destroyCsrf()
{
    unset($_SESSION[CSRF_SESSION_KEY]);

    unset($_SESSION[CSRF_TIME_KEY]);
}

/*
|--------------------------------------------------------------------------
| AJAX TOKEN
|--------------------------------------------------------------------------
*/

function verifyAjaxCsrf()
{
    $headers = [];

    if (function_exists('getallheaders')) {
        $headers = getallheaders();
    }

    $token = '';

    if (!empty($headers['X-CSRF-TOKEN'])) {

        $token = $headers['X-CSRF-TOKEN'];

    } elseif (!empty($_SERVER['HTTP_X_CSRF_TOKEN'])) {

        $token = $_SERVER['HTTP_X_CSRF_TOKEN'];

    }

    if (!verifyCsrf($token)) {

        jsonResponse(false, 'Invalid CSRF Token');

    }
}

/*
|--------------------------------------------------------------------------
| TOKEN META TAG
|--------------------------------------------------------------------------
*/

function csrfMeta()
{
    return '<meta name="csrf-token" content="' .
        csrfToken() .
        '">';
}