<?php

define('APP_START', true);

session_start();

date_default_timezone_set('Asia/Kolkata');

error_reporting(E_ALL);
ini_set('display_errors',1);

require_once __DIR__.'/database.php';


define('APP_NAME','Telegram Broadcast');

define('BASE_URL','');

define('UPLOAD_PATH', dirname(__DIR__) . '/uploads/');

define('PHOTO_PATH', UPLOAD_PATH . 'photos/');

define('VIDEO_PATH', UPLOAD_PATH . 'videos/');

define('DOCUMENT_PATH', UPLOAD_PATH . 'documents/');


define('PHOTO_URL','uploads/photos/');

define('VIDEO_URL','uploads/videos/');

define('DOCUMENT_URL','uploads/documents/');


define('MAX_PHOTOS',10);

define('MAX_FILE_SIZE',100 * 1024 * 1024);

define('QUEUE_CHUNK',500);

define('MULTI_CURL_LIMIT',30);

define('AJAX_REFRESH',2000);


if(!is_dir(PHOTO_PATH)){
    mkdir(PHOTO_PATH,0777,true);
}

if(!is_dir(VIDEO_PATH)){
    mkdir(VIDEO_PATH,0777,true);
}

if(!is_dir(DOCUMENT_PATH)){
    mkdir(DOCUMENT_PATH,0777,true);
}