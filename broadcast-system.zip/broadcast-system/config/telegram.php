<?php

if (!defined('APP_START')) {
    exit;
}

$stmt = $pdo->query("SELECT * FROM settings LIMIT 1");
$settings = $stmt->fetch();

$BOT_TOKEN = trim($settings['bot_token'] ?? '');

$BOT_USERNAME = trim($settings['bot_username'] ?? '');

define('BOT_TOKEN',$BOT_TOKEN);

define('BOT_USERNAME',$BOT_USERNAME);

define(
    'TELEGRAM_API',
    "https://api.telegram.org/bot".BOT_TOKEN."/"
);

function telegramRequest($method,$params=[]){

    $ch = curl_init();

    curl_setopt_array($ch,[

        CURLOPT_URL=>TELEGRAM_API.$method,

        CURLOPT_POST=>true,

        CURLOPT_POSTFIELDS=>$params,

        CURLOPT_RETURNTRANSFER=>true,

        CURLOPT_CONNECTTIMEOUT=>20,

        CURLOPT_TIMEOUT=>60,

        CURLOPT_SSL_VERIFYPEER=>false

    ]);

    $result=curl_exec($ch);

    curl_close($ch);

    return $result;

}